/// Ortam ayarlari. Uretimde --dart-define ile gecin:
///   flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=... --dart-define=API_BASE=...
class Config {
  static const supabaseUrl =
      String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://XXXX.supabase.co');
  static const supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'ANON_KEY');
  /// Cloud Run servisinin adresi (sondaki / olmadan)
  static const apiBase =
      String.fromEnvironment('API_BASE', defaultValue: 'https://meetmind-api-xxxx.a.run.app');
  static const recordingsBucket = 'recordings';
}
