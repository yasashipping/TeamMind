/// meetings tablosunun satir modeli.
/// status: recording -> uploaded -> transcribing -> analyzing -> done | error
class Meeting {
  final String id;
  final String userId;
  final String title;
  final DateTime createdAt;
  final String status;
  final int? durationSec;
  final String? audioPath;
  final String? reportMd;
  final List<dynamic> items; // decision/action_item/risk/... maddeleri (JSON)
  final String? errorMessage;

  Meeting({
    required this.id,
    required this.userId,
    required this.title,
    required this.createdAt,
    required this.status,
    this.durationSec,
    this.audioPath,
    this.reportMd,
    this.items = const [],
    this.errorMessage,
  });

  factory Meeting.fromJson(Map<String, dynamic> j) => Meeting(
        id: j['id'],
        userId: j['user_id'],
        title: j['title'] ?? 'Toplantı',
        createdAt: DateTime.parse(j['created_at']).toLocal(),
        status: j['status'] ?? 'recording',
        durationSec: j['duration_sec'],
        audioPath: j['audio_path'],
        reportMd: j['report_md'],
        items: (j['items'] as List?) ?? const [],
        errorMessage: j['error_message'],
      );

  bool get isDone => status == 'done';
  bool get isProcessing =>
      status == 'uploaded' || status == 'transcribing' || status == 'analyzing';

  String get statusLabel => switch (status) {
        'recording' => 'Kaydediliyor',
        'uploaded' => 'Yüklendi, sırada',
        'transcribing' => 'Yazıya dökülüyor',
        'analyzing' => 'Analiz ediliyor',
        'done' => 'Hazır',
        'error' => 'Hata',
        _ => status,
      };
}
