import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

/// Basla-bitir kayit modeli. Kayit cihazda tek dosya olarak tutulur,
/// bitince yuklenir. Surekli arka plan dinleme YOK.
class RecorderService {
  final _recorder = AudioRecorder();
  DateTime? _startedAt;
  String? _path;

  bool get isRecording => _startedAt != null;
  Duration get elapsed =>
      _startedAt == null ? Duration.zero : DateTime.now().difference(_startedAt!);

  Future<bool> ensurePermission() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<void> start(String meetingId) async {
    if (!await _recorder.hasPermission()) {
      throw Exception('Mikrofon izni verilmedi');
    }
    final dir = await getTemporaryDirectory();
    _path = '${dir.path}/$meetingId.m4a';
    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc, // Google STT & Whisper ikisi de okur
        bitRate: 64000,
        sampleRate: 16000, // STT icin yeterli, dosya kucuk kalir
        numChannels: 1,
      ),
      path: _path!,
    );
    _startedAt = DateTime.now();
  }

  /// Dosya yolunu ve sureyi dondurur.
  Future<({File file, int durationSec})> stop() async {
    final path = await _recorder.stop();
    final dur = elapsed.inSeconds;
    _startedAt = null;
    if (path == null) throw Exception('Kayıt dosyası oluşmadı');
    return (file: File(path), durationSec: dur);
  }

  Future<void> cancel() async {
    await _recorder.cancel();
    _startedAt = null;
  }

  void dispose() => _recorder.dispose();
}
