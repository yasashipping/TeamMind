import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../models/meeting.dart';

/// Akis:
///   1. createMeeting()    -> meetings satiri (status=recording)
///   2. uploadAndProcess() -> Storage'a yukle, status=uploaded, Cloud Run'i durt
///   3. watch()            -> Realtime ile satir degisimini izle (transcribing/analyzing/done)
class MeetingService {
  final _client = Supabase.instance.client;

  Future<Meeting> createMeeting({String? title}) async {
    final row = await _client
        .from('meetings')
        .insert({
          'user_id': _client.auth.currentUser!.id,
          'title': title ?? 'Toplantı ${DateTime.now().toString().substring(0, 16)}',
          'status': 'recording',
        })
        .select()
        .single();
    return Meeting.fromJson(row);
  }

  Future<List<Meeting>> listMeetings() async {
    final rows = await _client
        .from('meetings')
        .select()
        .order('created_at', ascending: false);
    return (rows as List).map((r) => Meeting.fromJson(r)).toList();
  }

  Future<void> uploadAndProcess(Meeting m, File audio, int durationSec) async {
    final userId = _client.auth.currentUser!.id;
    final storagePath = '$userId/${m.id}.m4a';

    // 1) Ses dosyasini Supabase Storage'a yukle
    await _client.storage.from(Config.recordingsBucket).upload(
          storagePath,
          audio,
          fileOptions: const FileOptions(contentType: 'audio/mp4', upsert: true),
        );

    // 2) Satiri guncelle
    await _client.from('meetings').update({
      'status': 'uploaded',
      'audio_path': storagePath,
      'duration_sec': durationSec,
    }).eq('id', m.id);

    // 3) Cloud Run'i tetikle (backend isi arka plana alir, hemen doner)
    final token = _client.auth.currentSession!.accessToken;
    final res = await http.post(
      Uri.parse('${Config.apiBase}/process'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'meeting_id': m.id}),
    );
    if (res.statusCode >= 300) {
      throw Exception('Backend hata ${res.statusCode}: ${res.body}');
    }
  }

  /// Tek bir toplantinin satirini canli izle.
  Stream<Meeting> watch(String meetingId) => _client
      .from('meetings')
      .stream(primaryKey: ['id'])
      .eq('id', meetingId)
      .map((rows) => Meeting.fromJson(rows.first));

  Future<void> deleteMeeting(Meeting m) async {
    if (m.audioPath != null) {
      await _client.storage.from(Config.recordingsBucket).remove([m.audioPath!]);
    }
    await _client.from('meetings').delete().eq('id', m.id);
  }
}
