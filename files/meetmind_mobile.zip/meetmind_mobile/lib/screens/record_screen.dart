import 'dart:async';
import 'package:flutter/material.dart';
import '../models/meeting.dart';
import '../services/meeting_service.dart';
import '../services/recorder_service.dart';
import 'report_screen.dart';

/// Basla -> (sayac) -> Bitir -> yukle -> rapor ekranina gec.
class RecordScreen extends StatefulWidget {
  const RecordScreen({super.key});
  @override
  State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen> {
  final _rec = RecorderService();
  final _svc = MeetingService();
  final _title = TextEditingController();
  Meeting? _meeting;
  Timer? _tick;
  bool _consent = false;
  bool _uploading = false;
  String? _err;

  @override
  void dispose() {
    _tick?.cancel();
    _rec.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    if (!await _rec.ensurePermission()) {
      setState(() => _err = 'Mikrofon izni gerekli.');
      return;
    }
    try {
      final m = await _svc.createMeeting(
          title: _title.text.trim().isEmpty ? null : _title.text.trim());
      await _rec.start(m.id);
      _tick = Timer.periodic(const Duration(seconds: 1), (_) => setState(() {}));
      setState(() { _meeting = m; _err = null; });
    } catch (e) {
      setState(() => _err = e.toString());
    }
  }

  Future<void> _stop() async {
    _tick?.cancel();
    setState(() => _uploading = true);
    try {
      final r = await _rec.stop();
      await _svc.uploadAndProcess(_meeting!, r.file, r.durationSec);
      await r.file.delete(); // cihazda ses birakma
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => ReportScreen(meetingId: _meeting!.id)));
    } catch (e) {
      setState(() { _err = e.toString(); _uploading = false; });
    }
  }

  String _fmt(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final recording = _rec.isRecording;
    return Scaffold(
      appBar: AppBar(title: const Text('Yeni toplantı')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            if (!recording) ...[
              TextField(
                controller: _title,
                decoration: const InputDecoration(labelText: 'Toplantı başlığı (isteğe bağlı)'),
              ),
              const SizedBox(height: 16),
              // KVKK/GDPR: kaydeden taraf katilimcilari bilgilendirmeli.
              CheckboxListTile(
                value: _consent,
                onChanged: (v) => setState(() => _consent = v ?? false),
                title: const Text('Tüm katılımcılar kaydın yapıldığından haberdar edildi.'),
                controlAffinity: ListTileControlAffinity.leading,
              ),
            ],
            const Spacer(),
            Text(
              _fmt(_rec.elapsed),
              style: Theme.of(context).textTheme.displayLarge?.copyWith(
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
            ),
            const SizedBox(height: 8),
            Text(recording ? 'Kayıt sürüyor…' : 'Hazır',
                style: Theme.of(context).textTheme.bodyLarge),
            if (_err != null) ...[
              const SizedBox(height: 12),
              Text(_err!, style: const TextStyle(color: Colors.red)),
            ],
            const Spacer(),
            if (_uploading)
              const Column(children: [
                CircularProgressIndicator(),
                SizedBox(height: 8),
                Text('Yükleniyor…'),
              ])
            else if (!recording)
              FilledButton.icon(
                onPressed: _consent ? _start : null,
                icon: const Icon(Icons.fiber_manual_record),
                label: const Text('Başlat'),
                style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(56)),
              )
            else
              FilledButton.icon(
                onPressed: _stop,
                icon: const Icon(Icons.stop),
                label: const Text('Bitir ve rapor üret'),
                style: FilledButton.styleFrom(
                    backgroundColor: Colors.red,
                    minimumSize: const Size.fromHeight(56)),
              ),
          ],
        ),
      ),
    );
  }
}
