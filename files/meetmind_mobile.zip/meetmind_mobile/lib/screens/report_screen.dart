import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../models/meeting.dart';
import '../services/meeting_service.dart';

/// Satiri Realtime ile izler; islem bitince raporu markdown olarak gosterir.
class ReportScreen extends StatelessWidget {
  final String meetingId;
  const ReportScreen({super.key, required this.meetingId});

  static const _steps = ['uploaded', 'transcribing', 'analyzing', 'done'];

  @override
  Widget build(BuildContext context) {
    final svc = MeetingService();
    return StreamBuilder<Meeting>(
      stream: svc.watch(meetingId),
      builder: (context, snap) {
        final m = snap.data;
        return Scaffold(
          appBar: AppBar(
            title: Text(m?.title ?? 'Rapor'),
            actions: [
              if (m?.reportMd != null)
                IconButton(
                  icon: const Icon(Icons.copy),
                  tooltip: 'Raporu kopyala',
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: m!.reportMd!));
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Kopyalandı')));
                  },
                ),
            ],
          ),
          body: m == null
              ? const Center(child: CircularProgressIndicator())
              : m.status == 'error'
                  ? _ErrorView(m.errorMessage)
                  : m.isDone
                      ? Markdown(data: m.reportMd ?? '_Rapor boş_')
                      : _ProgressView(m),
        );
      },
    );
  }
}

class _ProgressView extends StatelessWidget {
  final Meeting m;
  const _ProgressView(this.m);

  @override
  Widget build(BuildContext context) {
    final idx = ReportScreen._steps.indexOf(m.status);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(m.statusLabel, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text('Adım ${idx < 0 ? 1 : idx + 1} / 3 · Ekranı kapatabilirsiniz, '
              'rapor listede görünür.',
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String? msg;
  const _ErrorView(this.msg);
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('İşlem başarısız:\n${msg ?? "bilinmeyen hata"}',
              textAlign: TextAlign.center),
        ),
      );
}
