import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/meeting.dart';
import '../services/auth_service.dart';
import '../services/meeting_service.dart';
import 'record_screen.dart';
import 'report_screen.dart';

class MeetingsScreen extends StatefulWidget {
  const MeetingsScreen({super.key});
  @override
  State<MeetingsScreen> createState() => _MeetingsScreenState();
}

class _MeetingsScreenState extends State<MeetingsScreen> {
  final _svc = MeetingService();
  late Future<List<Meeting>> _future = _svc.listMeetings();

  void _refresh() => setState(() => _future = _svc.listMeetings());

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('d MMM yyyy HH:mm', 'tr');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Toplantılarım'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthService().signOut(),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: FutureBuilder<List<Meeting>>(
          future: _future,
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final list = snap.data!;
            if (list.isEmpty) {
              return const Center(child: Text('Henüz kayıt yok. Aşağıdan başlat.'));
            }
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, i) {
                final m = list[i];
                return ListTile(
                  leading: Icon(
                    m.isDone
                        ? Icons.description
                        : m.status == 'error'
                            ? Icons.error_outline
                            : Icons.hourglass_top,
                    color: m.status == 'error' ? Colors.red : null,
                  ),
                  title: Text(m.title),
                  subtitle: Text(
                    '${fmt.format(m.createdAt)} · ${m.statusLabel}'
                    '${m.durationSec != null ? ' · ${m.durationSec! ~/ 60} dk' : ''}',
                  ),
                  onTap: () async {
                    await Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ReportScreen(meetingId: m.id)));
                    _refresh();
                  },
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.fiber_manual_record, color: Colors.red),
        label: const Text('Toplantı başlat'),
        onPressed: () async {
          await Navigator.push(
              context, MaterialPageRoute(builder: (_) => const RecordScreen()));
          _refresh();
        },
      ),
    );
  }
}
