-- MeetMind Supabase semasi. Supabase SQL Editor'da calistirin.

create extension if not exists "pgcrypto";

create table if not exists public.meetings (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  title         text not null default 'Toplantı',
  status        text not null default 'recording'
                check (status in ('recording','uploaded','transcribing','analyzing','done','error')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  duration_sec  int,
  audio_path    text,               -- storage: recordings/<user_id>/<id>.m4a
  transcript    text,               -- "satir | sure | metin" formati (run_analyze ile uyumlu)
  report_md     text,               -- run_analyze'in urettigi rapor
  items         jsonb not null default '[]'::jsonb,  -- kept_items (type/text/owner/deadline/confidence)
  executive_summary text,
  error_message text
);

create index if not exists meetings_user_created on public.meetings(user_id, created_at desc);

-- updated_at otomatik
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists meetings_touch on public.meetings;
create trigger meetings_touch before update on public.meetings
  for each row execute function public.touch_updated_at();

-- RLS: herkes yalniz kendi toplantisini gorur
alter table public.meetings enable row level security;
create policy "own meetings select" on public.meetings for select using (auth.uid() = user_id);
create policy "own meetings insert" on public.meetings for insert with check (auth.uid() = user_id);
create policy "own meetings update" on public.meetings for update using (auth.uid() = user_id);
create policy "own meetings delete" on public.meetings for delete using (auth.uid() = user_id);

-- Realtime (Flutter watch() icin)
alter publication supabase_realtime add table public.meetings;

-- Storage bucket: recordings (private)
insert into storage.buckets (id, name, public) values ('recordings','recordings', false)
  on conflict (id) do nothing;

create policy "own recordings insert" on storage.objects for insert
  with check (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own recordings select" on storage.objects for select
  using (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "own recordings delete" on storage.objects for delete
  using (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);

-- Backend service_role anahtariyla calisir, RLS'i asar; ses dosyasini isledikten
-- sonra siler (gizlilik). Ek olarak 24 saatten eski dosyalar icin pg_cron ile temizlik
-- eklenebilir (ileride).
